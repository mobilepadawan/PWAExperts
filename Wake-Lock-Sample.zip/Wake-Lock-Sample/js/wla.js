document.addEventListener("DOMContentLoaded", () => {
    let wakeLock = navigator.wakeLock
    const p = document.querySelector("p")
    try {
        wakeLock.request("screen");
        console.log("Screen Wake Lock is active");
        p.innerHTML = "Screen Wake Lock is active"
      } catch (err) {
        console.error(err);
      }    
})